"""ARC CLI template package."""
